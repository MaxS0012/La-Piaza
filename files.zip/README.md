# 🍕 La Piazza

Aplicación web de pizzería con integración a Supabase, GitHub Actions CI/CD y desplegable en Vercel.

## 🚀 Setup rápido

### 1. Supabase
1. Crea un proyecto en [supabase.com](https://supabase.com)
2. Ve a **SQL Editor** y ejecuta el contenido de `supabase_schema.sql`
3. En **Project Settings > API**, copia:
   - `Project URL`
   - `anon public key`
4. Edita `index.html` y reemplaza en la sección CONFIG:
   ```js
   const SUPABASE_URL = 'https://TU-PROYECTO.supabase.co'
   const SUPABASE_KEY = 'TU-ANON-KEY'
   ```

### 2. GitHub
1. Crea un repositorio en GitHub
2. Sube todos los archivos:
   ```bash
   git init
   git add .
   git commit -m "feat: La Piazza initial commit"
   git remote add origin https://github.com/TU-USUARIO/la-piazza.git
   git push -u origin main
   ```

### 3. Vercel
**Opción A – Automático desde GitHub:**
1. Ve a [vercel.com](https://vercel.com) y conecta tu repositorio
2. Vercel detecta `vercel.json` y despliega automáticamente

**Opción B – GitHub Actions CI/CD:**
1. En Vercel: crea el proyecto y obtén `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
2. En GitHub → Settings → Secrets, agrega esas 3 variables
3. Cada push a `main` disparará el deploy automático

## 📋 Funcionalidades
- 🍕 Menú completo con todas las pizzas
- 🛒 Carrito de compras funcional
- 📦 Sistema de órdenes guardadas en Supabase
- 📊 Vista de todas las órdenes
- ✅ Estados de orden en tiempo real
- 🔢 Generación automática de número de orden

## 🎨 Stack
- **Frontend**: HTML5 + CSS3 + Vanilla JS
- **Base de datos**: Supabase (PostgreSQL)
- **Deploy**: Vercel
- **CI/CD**: GitHub Actions
